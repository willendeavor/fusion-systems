intrinsic FusionRecordTemp() -> Rec 
 {} 

    FusionRecord := recformat<
		p : RngIntElt,
		S : Grp, 
		S_order: RngIntElt,
		S_name : MonStgElt,
		S_small_group_id : Tup, 
		EssentialData : SeqEnum,
		core : Grp, 
		core_trivial : BoolElt,
		pPerfect: BoolElt,
		focal_subgroup : Grp,
		fusion_group_name : MonStgElt,
		fusion_group : Grp
		>;

	EssentialRecord := recformat< 
		E : Grp, 
		E_order : RngIntElt,
		E_name : MonStgElt,
		AutFE_order : RngIntElt,
		AutFE_name : MonStgElt,
		AutFE_gens : SeqEnum
		>; 

  S :=PCGroup(\[ 6, -2, 2, 2, -2, 2, 2, 362, 116, 158 ])
; 
EssentialData := [];

E := sub<S | { S.1, S.2, S.3, S.5, S.4, S.6 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1, S.2, S.3, S.5, S.4, S.6 }>, 
E_order := 64, 
E_name := "C2^5.C2", 
AutFE_order := 8, 
AutFE_gens := [
[ <E.1, E.1>, <E.2, E.2>, <E.3, E.3 * E.5>, <E.4, E.4>, <E.5, E.5>, <E.6, E.6> ],
[ <E.1, E.1>, <E.2, E.2>, <E.3, E.3 * E.4>, <E.4, E.4>, <E.5, E.5>, <E.6, E.6> ],
[ <E.1, E.1 * E.5>, <E.2, E.2 * E.4>, <E.3, E.3>, <E.4, E.4>, <E.5, E.5>, <E.6, E.6> ]
], 
AutFE_name := "C2^3" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.1, S.2, S.5, S.4, S.6 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1, S.2, S.5, S.4, S.6 }>, 
E_order := 32, 
E_name := "C2^5", 
AutFE_order := 10, 
AutFE_gens := [
[ <E.1, E.1>, <E.2, E.1 * E.2>, <E.3, E.1 * E.3>, <E.4, E.1 * E.2 * E.3 * E.4 * E.5>, <E.5, E.5> ],
[ <E.1, E.1 * E.4>, <E.2, E.1 * E.2 * E.3 * E.4>, <E.3, E.1 * E.3 * E.4>, <E.4, E.1 * E.2 * E.5>, <E.5, E.5> ]
], 
AutFE_name := "D5" 
	>; 
Append(~EssentialData, ER); 
R := rec< FusionRecord |
p := 2,
S := S, 
S_order := 64,
S_name := "C2^5.C2",
S_small_group_id := <64, 60>,
EssentialData := EssentialData, 
core := sub<S | { S.1, S.2, S.5, S.4, S.6 }>, 
core_trivial := false, 
pPerfect := false, 
focal_subgroup := sub<S | { S.1, S.5, S.4, S.2 * S.4 * S.6 }> >; 
return R; 
end intrinsic;