intrinsic FusionRecordTemp() -> Rec 
 {} 

    FusionRecord := recformat<
		p : RngIntElt,
		S : Grp, 
		S_order: RngIntElt,
		S_name : MonStgElt,
		S_small_group_id : Tup, 
		EssentialData : SeqEnum,
		core : Grp, 
		core_trivial : BoolElt,
		pPerfect: BoolElt,
		focal_subgroup : Grp,
		fusion_group_name : MonStgElt,
		fusion_group : Grp
		>;

	EssentialRecord := recformat< 
		E : Grp, 
		E_order : RngIntElt,
		E_name : MonStgElt,
		AutFE_order : RngIntElt,
		AutFE_name : MonStgElt,
		AutFE_gens : SeqEnum
		>; 

  S :=PCGroup(\[ 5, -2, 2, -2, 2, -2, 40, 61, 302, 157, 72 ])
; 
EssentialData := [];

E := sub<S | { S.1, S.2, S.3, S.5, S.4 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1, S.2, S.3, S.5, S.4 }>, 
E_order := 32, 
E_name := "D4:C4", 
AutFE_order := 8, 
AutFE_gens := [
[ <E.1, E.1>, <E.2, E.2 * E.3>, <E.3, E.3 * E.5>, <E.4, E.4>, <E.5, E.5> ],
[ <E.1, E.1 * E.3 * E.5>, <E.2, E.2>, <E.3, E.3 * E.5>, <E.4, E.4>, <E.5, E.5> ]
], 
AutFE_name := "D4" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.2, S.5, S.4 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.2, S.5, S.4 }>, 
E_order := 8, 
E_name := "C2^3", 
AutFE_order := 6, 
AutFE_gens := [
[ <E.1, E.1 * E.3>, <E.2, E.2>, <E.3, E.1> ],
[ <E.1, E.3>, <E.2, E.2>, <E.3, E.1> ]
], 
AutFE_name := "S3" 
	>; 
Append(~EssentialData, ER); 
R := rec< FusionRecord |
p := 2,
S := S, 
S_order := 32,
S_name := "D4:C4",
S_small_group_id := <32, 9>,
EssentialData := EssentialData, 
core := sub<S | { S.4 }>, 
core_trivial := false, 
pPerfect := false, 
focal_subgroup := sub<S | { S.3, S.5, S.2 * S.5 }> >; 
return R; 
end intrinsic;