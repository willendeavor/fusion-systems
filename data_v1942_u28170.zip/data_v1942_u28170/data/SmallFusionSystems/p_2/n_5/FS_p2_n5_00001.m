intrinsic FusionRecordTemp() -> Rec 
 {} 

    FusionRecord := recformat<
		p : RngIntElt,
		S : Grp, 
		S_order: RngIntElt,
		S_name : MonStgElt,
		S_small_group_id : Tup, 
		EssentialData : SeqEnum,
		core : Grp, 
		core_trivial : BoolElt,
		pPerfect: BoolElt,
		focal_subgroup : Grp,
		fusion_group_name : MonStgElt,
		fusion_group : Grp
		>;

	EssentialRecord := recformat< 
		E : Grp, 
		E_order : RngIntElt,
		E_name : MonStgElt,
		AutFE_order : RngIntElt,
		AutFE_name : MonStgElt,
		AutFE_gens : SeqEnum
		>; 

  S :=PCGroup(\[ 5, -2, 2, -2, 2, -2, 101, 26, 72, 483, 248, 58 ])
; 
EssentialData := [];

E := sub<S | { S.1, S.2, S.3, S.5, S.4 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1, S.2, S.3, S.5, S.4 }>, 
E_order := 32, 
E_name := "C4wrC2", 
AutFE_order := 8, 
AutFE_gens := [
[ <E.1, E.1>, <E.2, E.2 * E.4>, <E.3, E.3>, <E.4, E.4 * E.5>, <E.5, E.5> ],
[ <E.1, E.1 * E.4 * E.5>, <E.2, E.2>, <E.3, E.3>, <E.4, E.4 * E.5>, <E.5, E.5> ],
[ <E.1, E.1 * E.5>, <E.2, E.2 * E.5>, <E.3, E.3>, <E.4, E.4>, <E.5, E.5> ],
[ <E.1, E.1 * E.5>, <E.2, E.2 * E.4 * E.5>, <E.3, E.3>, <E.4, E.4 * E.5>, <E.5, E.5> ]
], 
AutFE_name := "D4" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.4 * S.5, S.5, S.3 * S.4 * S.5, S.1 * S.2 * S.3 * S.4 * S.5 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.4 * S.5, S.5, S.3 * S.4 * S.5, S.1 * S.2 * S.3 * S.4 * S.5 }>, 
E_order := 16, 
E_name := "C4^2", 
AutFE_order := 6, 
AutFE_gens := [
[ <E.1, E.1 * E.2 * E.3 * E.4>, <E.2, E.1>, <E.3, E.3 * E.4>, <E.4, E.3> ],
[ <E.1, E.1 * E.2>, <E.2, E.2 * E.4>, <E.3, E.3 * E.4>, <E.4, E.4> ],
[ <E.1, E.1>, <E.2, E.2>, <E.3, E.3>, <E.4, E.4> ]
], 
AutFE_name := "S3" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.1 * S.3 * S.4, S.4 * S.5, S.3, S.5 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1 * S.3 * S.4, S.4 * S.5, S.3, S.5 }>, 
E_order := 16, 
E_name := "D4:C2", 
AutFE_order := 24, 
AutFE_gens := [
[ <E.1, E.1>, <E.2, E.2>, <E.3, E.3>, <E.4, E.4> ],
[ <E.1, E.1 * E.4>, <E.2, E.2>, <E.3, E.3>, <E.4, E.4> ],
[ <E.1, E.1>, <E.2, E.2>, <E.3, E.3 * E.4>, <E.4, E.4> ],
[ <E.1, E.1>, <E.2, E.2>, <E.3, E.1 * E.3>, <E.4, E.4> ],
[ <E.1, E.1 * E.3>, <E.2, E.2>, <E.3, E.1 * E.4>, <E.4, E.4> ]
], 
AutFE_name := "S4" 
	>; 
Append(~EssentialData, ER); 
R := rec< FusionRecord |
p := 2,
S := S, 
S_order := 32,
S_name := "C4wrC2",
S_small_group_id := <32, 11>,
EssentialData := EssentialData, 
core := sub<S | {}>, 
core_trivial := true, 
pPerfect := true, 
focal_subgroup := sub<S | { S.3 * S.4, S.4 * S.5, S.5, S.1 * S.2 * S.3, S.2 * S.4 }>, 
fusion_group := SL(3, GF(5))
, 
fusion_group_name := "PSL(3,5)" >; 
return R; 
end intrinsic;