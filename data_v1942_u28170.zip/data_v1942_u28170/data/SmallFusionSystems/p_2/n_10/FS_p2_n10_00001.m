intrinsic FusionRecordTemp() -> Rec 
 {} 

    FusionRecord := recformat<
		p : RngIntElt,
		S : Grp, 
		S_order: RngIntElt,
		S_name : MonStgElt,
		S_small_group_id : Tup, 
		EssentialData : SeqEnum,
		core : Grp, 
		core_trivial : BoolElt,
		pPerfect: BoolElt,
		focal_subgroup : Grp,
		fusion_group_name : MonStgElt,
		fusion_group : Grp
		>;

	EssentialRecord := recformat< 
		E : Grp, 
		E_order : RngIntElt,
		E_name : MonStgElt,
		AutFE_order : RngIntElt,
		AutFE_name : MonStgElt,
		AutFE_gens : SeqEnum
		>; 

  S :=PCGroup(\[ 10, -2, 2, 2, 2, -2, 2, 2, -2, -2, -2, 320, 361, 651, 20282, 1032, 
10563, 12653, 7204, 3614, 1734, 844, 27855, 4345, 4115, 1125, 1015, 31366, 7316,
1446, 1876, 71687, 35857, 17947, 6437, 1657, 867, 397, 69128, 34578 ])
; 
EssentialData := [];

E := sub<S | { S.1, S.2, S.9, S.3, S.5, S.10, S.8, S.4, S.7, S.6 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1, S.2, S.9, S.3, S.5, S.10, S.8, S.4, S.7, S.6 }>, 
E_order := 1024, 
E_name := "(C2*D4).D4^2", 
AutFE_order := 512, 
AutFE_gens := [
[ <E.1, E.1 * E.9>, <E.2, E.2 * E.5 * E.6 * E.7 * E.10>, <E.3, E.3>, <E.4, E.4>, <E.5, E.5 * E.9>, <E.6, E.6 * E.10>, <E.7, E.7 * E.9 * E.10>, <E.8, E.8 * E.10>, <E.9, E.9>, <E.10, E.10> ],
[ <E.1, E.1 * E.6 * E.8>, <E.2, E.2 * E.7>, <E.3, E.3>, <E.4, E.4>, <E.5, E.5>, <E.6, E.6 * E.9>, <E.7, E.7>, <E.8, E.8 * E.9 * E.10>, <E.9, E.9>, <E.10, E.10> ],
[ <E.1, E.1>, <E.2, E.2 * E.5>, <E.3, E.3 * E.6 * E.8 * E.10>, <E.4, E.4 * E.9>, <E.5, E.5 * E.8>, <E.6, E.6>, <E.7, E.7 * E.8 * E.9>, <E.8, E.8 * E.9 * E.10>, <E.9, E.9 * E.10>, <E.10, E.10> ],
[ <E.1, E.1 * E.5 * E.9>, <E.2, E.2>, <E.3, E.3 * E.7>, <E.4, E.4 * E.5 * E.6 * E.7 * E.10>, <E.5, E.5 * E.8>, <E.6, E.6 * E.8 * E.9 * E.10>, <E.7, E.7>, <E.8, E.8 * E.9 * E.10>, <E.9, E.9 * E.10>, <E.10, E.10> ]
], 
AutFE_name := "C2.C2^6.C2^2" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.2, S.3, S.8 * S.9 * S.10, S.10, S.4, S.5 * S.6 * S.7 * S.10, S.7, S.9 * S.10, S.6 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.2, S.3, S.8 * S.9 * S.10, S.10, S.4, S.5 * S.6 * S.7 * S.10, S.7, S.9 * S.10, S.6 }>, 
E_order := 512, 
E_name := "C2^2.C2^6.C2", 
AutFE_order := 1536, 
AutFE_gens := [
[ <E.1, E.1>, <E.2, E.2 * E.6>, <E.3, E.3 * E.5>, <E.4, E.4 * E.7>, <E.5, E.5 * E.8>, <E.6, E.6>, <E.7, E.7 * E.8 * E.9>, <E.8, E.8 * E.9>, <E.9, E.9> ],
[ <E.1, E.1 * E.2 * E.3 * E.6>, <E.2, E.3 * E.5 * E.7 * E.9>, <E.3, E.2 * E.4 * E.5 * E.8 * E.9>, <E.4, E.2 * E.3 * E.6 * E.7>, <E.5, E.6 * E.7 * E.8>, <E.6, E.5 * E.9>, <E.7, E.5 * E.6 * E.8>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.6>, <E.2, E.2>, <E.3, E.3>, <E.4, E.4 * E.8 * E.9>, <E.5, E.5 * E.8 * E.9>, <E.6, E.6>, <E.7, E.7 * E.8>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.5 * E.6>, <E.2, E.2 * E.8>, <E.3, E.3 * E.8 * E.9>, <E.4, E.4 * E.9>, <E.5, E.5 * E.8>, <E.6, E.6 * E.8 * E.9>, <E.7, E.7 * E.8>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.2 * E.3>, <E.2, E.3 * E.5 * E.7 * E.8>, <E.3, E.2 * E.5 * E.7 * E.8>, <E.4, E.2 * E.3 * E.4 * E.6 * E.7>, <E.5, E.6 * E.8>, <E.6, E.5 * E.8 * E.9>, <E.7, E.5 * E.6 * E.7 * E.8 * E.9>, <E.8, E.8 * E.9>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.7>, <E.2, E.2>, <E.3, E.3 * E.9>, <E.4, E.4 * E.8>, <E.5, E.5 * E.8>, <E.6, E.6 * E.8 * E.9>, <E.7, E.7 * E.8 * E.9>, <E.8, E.8>, <E.9, E.9> ]
], 
AutFE_name := "C2^3.(D4*S4)" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.5 * S.6 * S.7 * S.8, S.10, S.1 * S.2, S.9 * S.10, S.3, S.4, S.8 * S.9 * S.10, S.7, S.6 * S.7 * S.9 * S.10 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.5 * S.6 * S.7 * S.8, S.10, S.1 * S.2, S.9 * S.10, S.3, S.4, S.8 * S.9 * S.10, S.7, S.6 * S.7 * S.9 * S.10 }>, 
E_order := 512, 
E_name := "C4^2.C2^4.C2", 
AutFE_order := 768, 
AutFE_gens := [
[ <E.1, E.1 * E.2>, <E.2, E.2>, <E.3, E.3>, <E.4, E.2 * E.4 * E.5 * E.6 * E.7 * E.9>, <E.5, E.5 * E.6 * E.8 * E.9>, <E.6, E.6 * E.8 * E.9>, <E.7, E.6 * E.7 * E.8 * E.9>, <E.8, E.9>, <E.9, E.8> ],
[ <E.1, E.1 * E.8 * E.9>, <E.2, E.2 * E.6>, <E.3, E.3 * E.5 * E.7 * E.8 * E.9>, <E.4, E.4 * E.7 * E.9>, <E.5, E.5>, <E.6, E.6 * E.8>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.7>, <E.2, E.2>, <E.3, E.3 * E.9>, <E.4, E.4 * E.8 * E.9>, <E.5, E.5>, <E.6, E.6 * E.8>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.8 * E.9>, <E.2, E.2>, <E.3, E.3>, <E.4, E.4>, <E.5, E.5 * E.9>, <E.6, E.6 * E.8 * E.9>, <E.7, E.7 * E.8>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.5 * E.7 * E.8 * E.9>, <E.2, E.2>, <E.3, E.3 * E.8 * E.9>, <E.4, E.4 * E.9>, <E.5, E.5 * E.9>, <E.6, E.6 * E.8 * E.9>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.2 * E.5 * E.6 * E.8 * E.9>, <E.2, E.4 * E.5 * E.6>, <E.3, E.3 * E.8>, <E.4, E.2 * E.4 * E.5 * E.8 * E.9>, <E.5, E.5 * E.6 * E.9>, <E.6, E.7 * E.8>, <E.7, E.6 * E.7 * E.8 * E.9>, <E.8, E.8 * E.9>, <E.9, E.8> ]
], 
AutFE_name := "C2^4.(S3*D4)" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.8 * S.10, S.9, S.5 * S.6 * S.7 * S.8 * S.10, S.1 * S.3, S.2 * S.3, S.10, S.4, S.7, S.6 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.8 * S.10, S.9, S.5 * S.6 * S.7 * S.8 * S.10, S.1 * S.3, S.2 * S.3, S.10, S.4, S.7, S.6 }>, 
E_order := 512, 
E_name := "C2^2.C2^5.C2^2", 
AutFE_order := 1536, 
AutFE_gens := [
[ <E.1, E.1 * E.7>, <E.2, E.2 * E.9>, <E.3, E.3 * E.8>, <E.4, E.4 * E.8>, <E.5, E.5 * E.9>, <E.6, E.6>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.7 * E.9>, <E.2, E.2 * E.6>, <E.3, E.3>, <E.4, E.4 * E.9>, <E.5, E.5 * E.7 * E.9>, <E.6, E.6 * E.9>, <E.7, E.7 * E.9>, <E.8, E.8 * E.9>, <E.9, E.9> ],
[ <E.1, E.1 * E.8>, <E.2, E.2 * E.6 * E.7 * E.8>, <E.3, E.3 * E.9>, <E.4, E.4>, <E.5, E.5 * E.8>, <E.6, E.6 * E.9>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.7>, <E.2, E.2>, <E.3, E.3 * E.6 * E.7>, <E.4, E.4 * E.7 * E.9>, <E.5, E.5>, <E.6, E.6 * E.9>, <E.7, E.7 * E.9>, <E.8, E.8 * E.9>, <E.9, E.9> ],
[ <E.1, E.2 * E.4 * E.5 * E.7 * E.8 * E.9>, <E.2, E.2 * E.6 * E.7 * E.8 * E.9>, <E.3, E.3 * E.6 * E.7>, <E.4, E.1 * E.5 * E.6 * E.7 * E.8>, <E.5, E.2 * E.5 * E.6>, <E.6, E.7 * E.8>, <E.7, E.7>, <E.8, E.6 * E.7>, <E.9, E.9> ],
[ <E.1, E.1 * E.2 * E.4 * E.9>, <E.2, E.5 * E.8 * E.9>, <E.3, E.3 * E.8>, <E.4, E.1 * E.5 * E.6 * E.8 * E.9>, <E.5, E.2 * E.5 * E.7 * E.9>, <E.6, E.7 * E.8>, <E.7, E.6>, <E.8, E.6 * E.7 * E.9>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.8>, <E.2, E.2 * E.6 * E.7 * E.8>, <E.3, E.3 * E.6 * E.7 * E.9>, <E.4, E.4 * E.7 * E.9>, <E.5, E.5 * E.7 * E.8>, <E.6, E.6>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ]
], 
AutFE_name := "C2^5.A4.C2^2" 
	>; 
Append(~EssentialData, ER); 

E := sub<S | { S.1, S.8 * S.10, S.9, S.3, S.5 * S.6, S.10, S.4, S.7, S.6 }>; 
ER := rec< EssentialRecord |
E := sub<S | { S.1, S.8 * S.10, S.9, S.3, S.5 * S.6, S.10, S.4, S.7, S.6 }>, 
E_order := 512, 
E_name := "C4.D4.C2^4", 
AutFE_order := 1536, 
AutFE_gens := [
[ <E.1, E.1 * E.6 * E.7 * E.9>, <E.2, E.2 * E.9>, <E.3, E.3>, <E.4, E.4 * E.8>, <E.5, E.5 * E.9>, <E.6, E.6 * E.8>, <E.7, E.7 * E.8 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.2 * E.3 * E.4 * E.5 * E.7 * E.8>, <E.2, E.2 * E.3 * E.6 * E.7 * E.8>, <E.3, E.3 * E.9>, <E.4, E.2 * E.3 * E.5 * E.7 * E.8>, <E.5, E.2 * E.4 * E.7 * E.9>, <E.6, E.7 * E.8>, <E.7, E.6 * E.8 * E.9>, <E.8, E.8 * E.9>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.7 * E.8>, <E.2, E.2 * E.6 * E.7>, <E.3, E.3 * E.8 * E.9>, <E.4, E.4 * E.7 * E.8 * E.9>, <E.5, E.5 * E.7 * E.8>, <E.6, E.6 * E.8 * E.9>, <E.7, E.7 * E.9>, <E.8, E.8 * E.9>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.7 * E.8 * E.9>, <E.2, E.2 * E.9>, <E.3, E.3 * E.9>, <E.4, E.4 * E.9>, <E.5, E.5 * E.8 * E.9>, <E.6, E.6 * E.8 * E.9>, <E.7, E.7 * E.8>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.4 * E.6 * E.7>, <E.2, E.3 * E.4 * E.6>, <E.3, E.4 * E.5 * E.8 * E.9>, <E.4, E.2 * E.3 * E.5 * E.7 * E.8>, <E.5, E.2 * E.4 * E.7 * E.8 * E.9>, <E.6, E.6 * E.7 * E.9>, <E.7, E.6 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.9>, <E.2, E.2 * E.8 * E.9>, <E.3, E.3 * E.9>, <E.4, E.4 * E.8>, <E.5, E.5 * E.8>, <E.6, E.6>, <E.7, E.7 * E.9>, <E.8, E.8>, <E.9, E.9> ],
[ <E.1, E.1 * E.6 * E.9>, <E.2, E.2 * E.9>, <E.3, E.3 * E.8>, <E.4, E.4 * E.8 * E.9>, <E.5, E.5>, <E.6, E.6 * E.9>, <E.7, E.7 * E.8>, <E.8, E.8>, <E.9, E.9> ]
], 
AutFE_name := "C2.C2^6.D6" 
	>; 
Append(~EssentialData, ER); 
R := rec< FusionRecord |
p := 2,
S := S, 
S_order := 1024,
S_name := "(C2*D4).D4^2",
S_small_group_id := <0, 0>,
EssentialData := EssentialData>;
return R; 
end intrinsic;